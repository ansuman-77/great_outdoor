package com.cg.iter.userservice;

import com.cg.iter.entity.User;

public interface UserService {
	void addUser();
	void findUserByName();
	public User findUserById(String userId);
	void findAllUsers();
	void editUser(String userId);
	void removeUser(String userId);

}
