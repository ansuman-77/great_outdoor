package com.cg.iter.userservice;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.iter.dao.UserDao;
import com.cg.iter.entity.User;

public class UserServiceImpl implements UserService {
	
	@Autowired
	UserDao dao;

	@Override
	public void addUser() {
		

	}

	@Override
	public void findUserByName() {
		// TODO Auto-generated method stub

	}

	@Override
	public User findUserById(String userId) {
		
		 User userinfo= dao.findUserById(userId);
		return userinfo;
	}

	@Override
	public void findAllUsers() {
		// TODO Auto-generated method stub

	}

	@Override
	public void editUser(String userId) {
		// TODO Auto-generated method stub

	}

	@Override
	public void removeUser(String userId) {
		// TODO Auto-generated method stub

	}

}
