package com.cg.iter.dao;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.iter.entity.User;

@Repository
public class UserDaoImpl implements UserDao {
	
	@Autowired
	EntityManager em ;

	@Override
	public void addUser() {
		

	}

	@Override
	public void findUserByName() {
		// TODO Auto-generated method stub

	}

	@Override
	public User findUserById(String userId) {
		return em.find(User.class,userId);

	}

	@Override
	public void findAllUsers() {
		

	}

	@Override
	public void editUser(String userId) {
		// TODO Auto-generated method stub

	}

	@Override
	public void removeUser(String userId) {
		// TODO Auto-generated method stub

	}

}
