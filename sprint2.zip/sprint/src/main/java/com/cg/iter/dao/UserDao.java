package com.cg.iter.dao;

import com.cg.iter.entity.User;

public interface UserDao {
	void addUser();
	void findUserByName();
	User findUserById(String userId);
	void findAllUsers();
	void editUser(String userId);
	void removeUser(String userId);
}
